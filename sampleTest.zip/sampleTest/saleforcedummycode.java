package sampleTest;

public class saleforcedummycode {
	 // WebDriverWait wait = new WebDriverWait(driver, 20);	
	 //WebElement e =driver.findElement(By.xpath("//input[@id='SubscriptionAgreement']"));
	// wait.until(ExpectedConditions.visibilityOfElementLocated (By.xpath("//input[@id='SubscriptionAgreement']"))).click();
//	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='_Lead.InfoEmail__c']"))).click();;
	// retryingFindClick( By.xpath("//input[@id='SubscriptionAgreement']"));
	 //driver.findElement(By.xpath("//*[@id='_Lead.EU_safeharbor_consent']")).click();
    //driver.findElement(By.xpath(	"//span[contains(.,'Start free trial')]")).click();
    
   
	/*public boolean retryingFindClick(By by) {
    boolean result = false;
    int attempts = 0;
    while(attempts < 2) {
        try {
            driver.findElement(by).click();
            result = true;
            break;
        } catch(StaleElementReferenceException e) {
        }
        attempts++;
    }
    return result;
}*/


//text verify and title of page

}
