package corejava;

public class ForLoopDemo {

	public static void main(String arg[]){
		
		for(int i=1;i<=10;i++){
			
			int table =2*i;
			System.out.println(table);
		}
	}
}
