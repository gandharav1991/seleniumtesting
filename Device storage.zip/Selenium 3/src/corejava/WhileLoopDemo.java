package corejava;

public class WhileLoopDemo {

	public static void main(String arg[]){
		int i = 1;
		while(i<=10){
			int table =2*i;
			System.out.println(table);
			i++;
		}
	}
}
