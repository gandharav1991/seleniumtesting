package corejava;

public class ControlStatement {

	public static void main(String arg[]){
		
		int marks =60;
		if(marks==60){
			
			System.out.println("1st division");
			
		}
		
		else if(marks==30){
			
			System.out.println("pass");
		}
		
		else{
			System.out.println("fail");
		}
		
	}
}
