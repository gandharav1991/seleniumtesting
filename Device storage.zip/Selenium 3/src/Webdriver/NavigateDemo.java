package Webdriver;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class NavigateDemo {

	
WebDriver driver;
	
	
	@Before
	public void setUp(){
		driver=new FirefoxDriver();	
		driver.manage().window().maximize();
	}
	
	@Test	
	public void atTest() throws Exception{
		
		//driver.get("https://www.facebook.com/");
		driver.navigate().to("https://www.facebook.com/");
		driver.findElement(By.xpath("//a[contains(.,'Forgotten account?')]")).click();
		Thread.sleep(5000);
		//driver.navigate().refresh();
		driver.navigate().back();
		Thread.sleep(5000);
		driver.navigate().forward();
	
	}
	@After
	public void tearDown(){
		
		//driver.close();
	}
}

