package Webdriver;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class OpenNewTabDemo {

WebDriver driver;
		
	@Before
	public void setUp(){
		driver=new FirefoxDriver();	
		driver.manage().window().maximize();
	}
	
	@Test	
	public void atTest() throws Exception{
		
		driver.get("https://www.google.co.in");
	    driver.findElement(By.tagName("html")).sendKeys(Keys.CONTROL+"t");
	    driver.get("http://www.bing.com/");
	    driver.findElement(By.tagName("html")).sendKeys(Keys.CONTROL+"t");
	}
	@After
	public void tearDown(){
		
		//driver.close();
	}
}

