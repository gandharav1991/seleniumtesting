package Webdriver;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class HandleDropdown {

	WebDriver driver;
	
	@Before
	public void setUp(){
		driver=new FirefoxDriver();	
		driver.manage().window().maximize();
	}
	
	@Test	
	public void atTest() throws Exception{
		
		driver.get("https://www.facebook.com/");
		
		new Select(driver.findElement(By.id("day"))).selectByIndex(20);
		new Select(driver.findElement(By.id("month"))).selectByValue("3");
		new Select(driver.findElement(By.id("year"))).selectByVisibleText("1990");
		

	}
	@After
	public void tearDown(){
		
		//driver.close();
	}
}


