package Webdriver;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ScrollBrowserDemo {

WebDriver driver;
	
	
	@Before
	public void setUp(){
		driver=new FirefoxDriver();	
		driver.manage().window().maximize();
	}
	
	@Test	
	public void atTest() throws Exception{
		
		driver.get("http://www.seleniumhq.org/");
		driver.findElement(By.tagName("html")).sendKeys(Keys.PAGE_DOWN);
		driver.findElement(By.tagName("html")).sendKeys(Keys.PAGE_DOWN);

	
	}
	@After
	public void tearDown(){
		
		//driver.close();
	}
}
