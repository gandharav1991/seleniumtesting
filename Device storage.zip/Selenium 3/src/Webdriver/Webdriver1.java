package Webdriver;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Webdriver1 {

	WebDriver driver;
	
	
	@Before
	public void setUp(){
		driver=new FirefoxDriver();	
		driver.manage().window().maximize();
	}
	
	@Test	
	public void atTest(){
		
		driver.get("https://www.facebook.com/");
		driver.findElement(By.id("email")).sendKeys("az@gmail.com");
		driver.findElement(By.id("pass")).sendKeys("123456");
		driver.findElement(By.id("loginbutton")).click();
	}
	@After
	public void tearDown(){
		
		//driver.close();
	}
}
