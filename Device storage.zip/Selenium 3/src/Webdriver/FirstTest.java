package Webdriver;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FirstTest {

	WebDriver driver;
	Dimension d= new Dimension(414,736);
	
	@Before
	public void atBefore(){
		
	driver =new FirefoxDriver();

	//driver.manage().window().maximize();
	driver.manage().window().setSize(d);
		
	}
	
	@Test
	public void atTest(){
	
		driver.get("https://www.facebook.com/");
		
	}
	
	
	@After
	public void atAfter(){
		
		//driver.close();
		//driver.quit();
	}
}
