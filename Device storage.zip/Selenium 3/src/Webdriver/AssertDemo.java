package Webdriver;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AssertDemo {

	String expectedTitle="Business Internet, Phone Services and Networking | Spectrum Business";
	WebDriver driver;
	
	@Before
	public void setUp(){
		driver=new FirefoxDriver();	
		driver.manage().window().maximize();
	}
	
	@Test	
	public void atTest() throws Exception{
		
		driver.get("https://business.spectrum.com");
		String actualTitle=driver.getTitle();
		
		
		
		if(actualTitle.equals(expectedTitle)){
			
			System.out.println("Pass");
		}
		else{
			
			System.out.println("Fail");
		}
		
		
		//Assert.assertEquals(expectedTitle, actualTitle);

	}
	@After
	public void tearDown(){
		
		//driver.close();
	}
}


