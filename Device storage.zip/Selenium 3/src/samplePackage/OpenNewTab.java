package samplePackage;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class OpenNewTab {

	WebDriver driver;

	@Before
	public void atBefore(){
		
		driver=new FirefoxDriver();
		driver.manage().window().maximize();
		
	}
	@Test
	public void atTest(){
		
		driver.get("https://www.facebook.com/");
		driver.findElement(By.tagName("html")).sendKeys(Keys.CONTROL+"t");
		driver.get("www.seleniumhq.org");
		driver.findElement(By.tagName("html")).sendKeys(Keys.CONTROL+"t");
		
		
	}
	@After
	public void atAfter(){
		
	driver.close();	
		
	}
}
