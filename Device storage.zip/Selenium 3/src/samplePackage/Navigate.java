package samplePackage;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Navigate {

	WebDriver driver;

	@Before
	public void atBefore(){
		
		driver=new FirefoxDriver();
		driver.manage().window().maximize();
		
	}
	@Test
	public void atTest() throws Exception{
		
     driver.navigate().to("http://www.seleniumhq.org/");
     
     driver.findElement(By.xpath("//*[@id='menu_documentation']/a")).click();
     Thread.sleep(1000);
     driver.navigate().back();
     Thread.sleep(1000);
     driver.navigate().forward();	
	}
	@After
	public void atAfter(){
		
	driver.close();	
		
	}
}
