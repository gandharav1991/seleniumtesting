package samplePackage;

public class JavaSample {

	public static void main(String[] args) {
		
		
		System.out.println("hello,\n\nHope you are doing well");

	}

}
