package samplePackage;
import org.junit.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;


public class WebdriverScript {
  private WebDriver driver;
  private String baseUrl;
 

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "https://www.facebook.com/";
   
  }

  @Test
  public void testWebdriverScript() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("email")).clear();
    driver.findElement(By.id("email")).sendKeys("az@gmail.com");
    driver.findElement(By.id("pass")).clear();
    driver.findElement(By.id("pass")).sendKeys("123456789");
    driver.findElement(By.id("u_0_q")).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    
  }
}
