package samplePackage;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class PopUP {

	WebDriver driver;
	String url;

	@Before
	public void atBefore() throws Exception{
		
		driver= new FirefoxDriver();
		driver.manage().window().maximize();
		
	}

	@Test
	public void atTest() throws Exception{
		
		driver.get("http://www.web-wise-wizard.com/javascript-tutorials/javascript-popup-alert-confirm-prompt.html");
		
		driver.findElement(By.xpath("//*[@id='mainContent']/ul[2]/li/div")).click();
		
		Thread.sleep(5000);
		System.out.println(driver.switchTo().alert().getText());		
		
		driver.switchTo().alert().dismiss();
		driver.switchTo().defaultContent();
		
		
		
		
}
}
