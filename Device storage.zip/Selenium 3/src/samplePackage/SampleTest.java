package samplePackage;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SampleTest {

WebDriver driver;

@After
public void atAfter(){
	
driver.close();	
	
}

@Before
public void atBefore(){
	
	driver=new FirefoxDriver();
	driver.manage().window().maximize();
	
}
@Test
public void atTest(){
	
	driver.get("https://www.coursera.org/?authMode=login");
	
	driver.findElement(By.name("email")).sendKeys("ayaz@gmail.com");
	
	driver.findElement(By.name("password")).sendKeys("123456");
	
	driver.findElement(By.cssSelector("form > button")).click();
	
	
}
}
