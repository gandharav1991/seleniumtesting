package samplePackage;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class completetest {

   WebDriver driver;
   
   
	 @Before
	 
	 public void before(){
	
		 driver= new FirefoxDriver();
		 driver.manage().window().maximize();
		 
		  }
	 
	 @Test
	 
	   public void test(){
		driver.get("https://www.olx.in"); 
		driver.findElement(By.xpath("//*[@id='topLoginLink']/span[2]/strong")).click();
		driver.findElement(By.xpath("//*[@id='userEmail']")).sendKeys("7417501344");
		driver.findElement(By.xpath("//*[@id='userPass']")).sendKeys("7417501344");
		driver.findElement(By.xpath("//*[@id='se_userLogin']")).click();
		 
		 
		 
		 
	 }
	 @After  
	 public void after(){
		 
		driver.close(); 
		 	 
		 
	 }
   
	   
	   
}
