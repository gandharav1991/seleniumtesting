package samplePackage;

import java.io.File;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;



public class MultipleBrowser {


	WebDriver driver;
	String url;

	@Before
	public void atBefore() throws Exception{

//=================================Firefox===========================		
		//driver= new FirefoxDriver();
		
		
//===================	HTMLUNITDRIVER===============================
		//driver = new HtmlUnitDriver();
		
//===================	Chrome===============================	
		
/*		File file = new File ("D:\\Study\\Selenium\\Driver\\drivers\\chromedriver_win32\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
		driver =new ChromeDriver();*/
		
//===================	IE===============================	
		
				File file = new File ("D:\\Study\\Selenium\\Driver\\drivers\\IEDriverServer_x64_2.53.1\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
				driver =new InternetExplorerDriver();		
        driver.manage().window().maximize();
	}

	@Test
	public void atTest() throws Exception{
		
		driver.get("http://www.web-wise-wizard.com/javascript-tutorials/javascript-popup-alert-confirm-prompt.html");
/*		driver.findElement(By.xpath("//*[@id='mainContent']/ul[2]/li/div")).click();
		Thread.sleep(5000);
		System.out.println(driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();*/
		
				
}
}

