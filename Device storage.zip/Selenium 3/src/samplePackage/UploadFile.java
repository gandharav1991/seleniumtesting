package samplePackage;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class UploadFile {

WebDriver driver;
	
	
	@Before
	public void atBefore(){
	
		driver=new FirefoxDriver();
		driver.manage().window().maximize();
		
	}
	@Test
	public void atTest(){
		
		driver.get("http://convertonlinefree.com/");
		
		driver.findElement(By.id("MainContent_fu")).sendKeys("C:\\Users\\Public\\Pictures\\Sample Pictures\\Tulips.jpg");
		driver.findElement(By.id("MainContent_btnConvert")).click();
	}
	
	@After
	public void atAfter(){
		
		
	}
}

