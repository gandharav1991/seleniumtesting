package TestNGSuiteDemo;

import org.testng.annotations.Test;

public class GoogleTest extends LaunchCloseBrowser {

	
	@Test
	public void google(){
		
		driver.get("https://www.google.co.in/");
		
		String s =driver.getTitle();
		System.out.println(s);
	}
}
