package TestNGSuiteDemo;

import org.testng.annotations.Test;

public class BingTest extends LaunchCloseBrowser {

	@Test
	public void bing(){
		
		driver.get("http://www.bing.com/");
		
		String s =driver.getTitle();
		System.out.println(s);
	}
}
