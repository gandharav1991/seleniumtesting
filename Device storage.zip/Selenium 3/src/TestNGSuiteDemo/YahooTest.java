package TestNGSuiteDemo;

import org.testng.annotations.Test;

public class YahooTest extends LaunchCloseBrowser {

	
	@Test
	public void yahoo(){
		
		driver.get("http://www.yahoo.com/");
		
		String s =driver.getTitle();
		System.out.println(s);
	}
}
