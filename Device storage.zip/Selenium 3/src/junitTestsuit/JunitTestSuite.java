package junitTestsuit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
	TestCase3.class,
	TestCase2.class,
	TestCase1.class
})

public class JunitTestSuite {

}
