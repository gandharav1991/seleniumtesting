package junitTestsuit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class TestCase1 {
	
	WebDriver driver;
	
	@Before
	public void atBefore(){
		  
		  driver = new FirefoxDriver();
		  
		  //driver = new HtmlUnitDriver();
		  
	}
	@Test
	  public void atTest(){
		  driver.get("https://www.google.co.in/?");
		  
		 String s =driver.getTitle();
		 System.out.println(s);

}
}
