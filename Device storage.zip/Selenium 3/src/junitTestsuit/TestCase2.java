package junitTestsuit;

import java.io.File;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class TestCase2 {

WebDriver driver;
	
	@Before
	public void atBefore(){
		  
		
		//---------------------------------Google Chrome-------------------------------------//	
		  
		File file =new File("D:\\Study\\Selenium\\Driver\\drivers\\chromedriver_win32\\chromedriver.exe");			
		System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
		driver= new ChromeDriver();
		  
		
	}
	@Test
	  public void atTest(){
		  driver.get("http://www.seleniumhq.org/");
		  
		 String s =driver.getTitle();
		 System.out.println(s);

}
}
