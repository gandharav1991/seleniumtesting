package junitTestsuit;

import java.io.File;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class TestCase3 {

WebDriver driver;
	
	@Before
	public void atBefore(){
		  
		
	
		  
		//-----------------------------------IE----------------------------------------------//
		  
		File file =new File("D:\\Study\\Selenium\\Driver\\drivers\\IEDriverServer_x64_2.53.1\\IEDriverServer.EXE");			
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		driver= new InternetExplorerDriver();
	}
	@Test
	  public void atTest(){
		  driver.get("http://www.bing.com/");
		  
		 String s =driver.getTitle();
		 System.out.println(s);

}
}
